# . exercise 1? 
# Please create a manual linear regression Using the cos j function and gradient descent

#import libraries

#  ?

#read data


#show data details


#draw data



#=========================================================================

# adding a new column called ones before the data


# separate X (training data) from y (target variable)




# convert from data frames to numpy matrices


#=========================================================================
# cost function



# GD function



# initialize variables for learning rate and iterations



# perform gradient descent to "fit" the model parameters




#=========================================================================

# get best fit line



# draw the line



# draw error graph



