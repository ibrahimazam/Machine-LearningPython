# . exercise 2? 
# Please create a manual Classificatio model  using sigmoid the cos J function and gradient descent

#import libraries

#  ?

#read data


#show data details



# isin 


#  print('Admitted Student \n ',positive )
#  print('Admitted negative \n ',negative )


#draw data


#=========================================================================
# cost sigmoid


# add a ones column - this makes the matrix multiplication work out easier


# set X (training data) and y (target variable)


# convert to numpy arrays and initalize the parameter array theta

# GD function


#draw


# costafteroptimize


#print ('accuracy = {0}%'.format(accuracy))
