import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats

# importing linear regression function
import sklearn.linear_model as lm

# function to calculate r-squared, MAE, RMSE
from sklearn.metrics import r2_score , mean_absolute_error, mean_squared_error

# Load data
df = pd.read_csv('C:/Demos/Module2/Data/Grade_Set_1.csv')
print(df)

# Simple scatter plot
df.plot(kind='scatter', x='Hours_Studied', y='Test_Grade', title='Grade vs Hours Studied')
plt.show()

# check the correlation between variables
print("Correlation Matrix: ")
df.corr()


# Create linear regression object
lr = lm.LinearRegression()

x= df.Hours_Studied[:, np.newaxis] # independent variable
y= df.Test_Grade.values            # dependent variable 

# Train the model using the training sets
lr.fit(x, y)
print ("Intercept: ", lr.intercept_)
print ("Coefficient: ", lr.coef_)

# manual prediction for a given value of x
print ("Manual prdiction :", 49.67777777777776 + 5.01666667*6)

# predict using the built-in function
print ("Using predict function: ", lr.predict([[6]]))

# plotting fitted line
plt.scatter(x, y,  color='black')
plt.plot(x, lr.predict(x), color='blue', linewidth=3)
plt.title('Grade vs Hours Studied')
plt.ylabel('Test_Grade')
plt.xlabel('Hours_Studied')
plt.show()

# Let's check the performance of fitted model through R-squared

# add predict value to the data frame
df['Test_Grade_Pred'] = lr.predict(x)

# Manually calculating R Squared
df['SST'] = np.square(df['Test_Grade'] - df['Test_Grade'].mean())
df['SSR'] = np.square(df['Test_Grade_Pred'] - df['Test_Grade'].mean())

print ("Sum of SSR:", df['SSR'].sum())
print ("Sum of SST:", df['SST'].sum())
print (df)

df.to_csv('r-squared.csv', index=False)
print ("R Squared using manual calculation: ", df['SSR'].sum() / df['SST'].sum())

# Using built-in function
print ("R Squared using built-in function: ", r2_score(df.Test_Grade,  df.Test_Grade_Pred))
print ("Mean Absolute Error: ", mean_absolute_error(df.Test_Grade, df.Test_Grade_Pred))
print ("Root Mean Squared Error: ", np.sqrt(mean_squared_error(df.Test_Grade, df.Test_Grade_Pred)))

# Load data
df = pd.read_csv('C:/Demos/Module2/Data/Grade_Set_1.csv')

df.loc[9] = np.array([5, 100])

x= df.Hours_Studied[:, np.newaxis] # independent variable
y= df.Test_Grade.values            # dependent variable 

# Train the model using the training sets
lr.fit(x, y)
print ("Intercept: ", lr.intercept_)
print ("Coefficient: ", lr.coef_)


# manual prediction for a given value of x
print ("Manual prdiction :", 54.4022988505747 + 4.64367816*6)


# predict using the built-in function
print ("Using predict function: ", lr.predict([[6]]))

# plotting fitted line
plt.scatter(x, y,  color='black')
plt.plot(x, lr.predict(x), color='blue', linewidth=3)
plt.title('Grade vs Hours Studied')
plt.ylabel('Test_Grade')
plt.xlabel('Hours_Studied')
plt.show()
# input('press <ENTER> to continue')

# add predict value to the data frame
df['Test_Grade_Pred'] = lr.predict(x)

# Using built-in function
print ("R Squared : ", r2_score(df.Test_Grade,  df.Test_Grade_Pred))
print ("Mean Absolute Error: ", mean_absolute_error(df.Test_Grade, df.Test_Grade_Pred))
print ("Root Mean Squared Error: ", np.sqrt(mean_squared_error(df.Test_Grade, df.Test_Grade_Pred)))