import numpy as np
import pandas as pd
###############
# Missing data
###############
# Python has two missing values: None and NaN.
# First, we'll look at None.
x = np.array([1,None,3]); print(x)
# If the None object is included, the result of the operation is an error.
print(sum(x))

# Next, we'll look at NaN.
# Arithmetic operations with NaN always result in NaN.
x = np.array([1,np.nan,3]); print(x)
print(sum(x))
# Numpy provides functions for performing operations by excluding NaN values.
print(np.nansum(x))

# In Pandas, None and NaN values are treated as NaN.
x = pd.DataFrame(np.arange(1.,5.,1.).reshape(2,2)); print(x)
x.iloc[0][0] = None; print(x)

# You can verify whether the dataframe element is NaN, 
# replace the NaN value with the specified value, or delete the entire row.
x['isnull'] = x[0].isnull()
x.fillna(100)
x.dropna()

###############
# Encoding
###############
'''
Create dummy variable:
This is a Boolean variable that indicates the presence of a category with the value 1 and 0 for absence. You should create k-1 dummy variables, where k is the number of level.
'''

import random
random.seed(2017)
import pandas as pd

df = pd.DataFrame({'A': ['high', 'medium', 'low'],
                   'B': [10,20,30]},
                    index=[0, 1, 2])
                   
print(df)

'''
Scikit-learn provides a useful function ‘One Hot Encoder’ to create a dummy variable for a given categorical variable
'''

df_with_dummies= pd.get_dummies(df, prefix='A', columns=['A'])
print(df_with_dummies)

'''

Convert categories to numeric labels
Another simple method is to represent the text description of each level with a number by using ‘Label Encoder’ function of Scikit-learn. If the number of levels are high (example zip code, state etc), then you apply the business logic to combine levels to groups. For example zip code or state can be combined to regions, however in this method there is a risk of losing critical information. Another method is to combine categories based on similar frequency (new category can be high, medium, low).
'''

import pandas as pd

# using pandas package's factorize function
df['A_pd_factorized'] = pd.factorize(df['A'])[0]

# Alternatively you can use sklearn package's LabelEncoder function
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()

df['A_LabelEncoded'] = le.fit_transform(df.A)
print(df)