'''
You are given an array points of size 300x2, 
where each row gives the (x, y) co-ordinates of a point on a map. 
Make a scatter plot of these points, and use the scatter plot
 to guess how many clusters there are.
'''

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
#Load the dataset (written for you).
df = pd.read_csv('C:/Demos/Module2/Data/Cluster_Set_1.csv')
points = df.values

#Create an array called xs that contains the values of points[:,0] - that is, column 0 of points:
xs = points[:,0]
#Create an array called ys that contains the values of points[:,1] - that is, column 1 of points
ys = points[:,1]


# Make a scatter plot by passing xs and ys to the plt.scatter() function.
plt.scatter(xs, ys)
plt.show()


'''
From the scatter plot of the previous exercise, you saw that the points 
seem to separate into 3 clusters. Now create a KMeans model to find 
3 clusters, and fit it to the data points from the previous exercise. 
After the model has been fit, obtain the cluster labels for points, and 
also for some new points using the .predict() method.
'''

# Using KMeans(), create a KMeans instance called model to find 3 clusters. To specify the number of clusters, use the n_clusters keyword argument

model = KMeans(n_clusters=3)
# Use the .fit() method of model to fit the model to the array of points points.
model.fit(points)
labels = model.predict(points)

# Use the .predict() method of model to predict the cluster labels of points, assigning the result to labels.
labels = model.predict(points)

#  Print out the labels, and have a look at them! (In the next exercise, I'll show you how to visualise this clustering better.)
print(labels)


# Make a scatter plot of xs and ys, specifying the c=labels keyword arguments to color the points by their cluster label. You'll see that KMeans has done a good job of identifying the clusters!
plt.scatter(xs, ys, c=labels)
plt.show()


# Obtain the coordinates of the centroids using the .cluster_centers_ attribute of model. Assign them to centroids.
centroids = model.cluster_centers_

# Assign column 0 of centroids to centroids_x, and column 1 of centroids to centroids_y.Assign column 0 of centroids to centroids_x, and column 1 of centroids to centroids_y.
centroids_x = centroids[:,0]
centroids_y = centroids[:,1]


plt.scatter(xs, ys, c=labels)
plt.scatter(centroids_x, centroids_y, marker='X', s=200)
plt.show()



